<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Ref_user extends CI_Controller
{

    var $path = 'backend/admin/ref_user/';
    var $table = 'user_';

    public function __construct()
    {
        parent::__construct();
        cek_role(1);
        $this->load->model($this->path . 'datatable', 'm_main');
    }

    public function index()
    {
        $data = [
            'title' => 'Referensi User',
            'uri_segment' => $this->path,
            'page' => $this->path . 'index',
            'script' => $this->path . 'index_js',
            'modal' => [
                $this->path . 'modal/modal_tambah',
                $this->path . 'modal/modal_ubah',
            ]
        ];

        $data['role'] = $this->db->get('user_role')->result();

        $this->templates->load($data);
    }

    function get_data()
    {
        $list = $this->m_main->get_datatables();
        $data = array();
        $no = $_GET['start'];
        foreach ($list as $field) {

            $no++;
            $row = array();

            $aksi = '
                <button type="button" class="btn btn-square btn-sm btn-danger tombol_hapus" data-id="' . $field->id . '">
                    <i class="fa fa-trash"></i>
                </button>
                <button type="button" class="btn btn-square btn-sm btn-success tombol_ubah" data-id="' . $field->id . '">
                    <i class="fa fa-edit"></i>
                </button>
            ';

            $row[] = $no;
            $row[] = $field->nama_role;
            $row[] = $field->username;
            $row[] = $aksi;


            $data[] = $row;
        }

        $output = array(
            "draw" => $_GET['draw'],
            "recordsTotal" => $this->m_main->count_all(),
            "recordsFiltered" => $this->m_main->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    public function store()
    {
        cek_post();
        $this->db->insert($this->table, [
            'role_id' => $this->input->post('role', true),
            'username' => $this->input->post('username', true),
            'password' => sha1($this->input->post('password', true)),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        echo json_encode([
            'status' => 'success',
            'msg' => 'Data berhasil disimpan'
        ]);
    }

    public function delete()
    {
        cek_post();
        $id = $this->input->post('id', true);
        $this->db->where('id', $id);
        $this->db->update($this->table, [
            'deleted_at' => date('Y-m-d H:i:s'),
            'is_active' => '0',
        ]);

        echo json_encode([
            'status' => 'success',
            'msg' => 'Data berhasil dihapus'
        ]);
    }

    public function get()
    {
        cek_post();
        $id = $this->input->post('id', true);
        $this->db->where('id', $id);
        $this->db->where('is_active', '1');
        $run = $this->db->get($this->table)->row();

        if ($run) {
            echo json_encode([
                'status' => 'success',
                'msg' => 'Data berhasil ditemukan',
                'data' => $run,
            ]);
        }
    }

    public function update()
    {
        cek_post();
        $pass = $this->input->post('password', true);

        if ($pass) {
            $this->db->set('password', sha1($pass));
        }

        $this->db->where('id', $this->input->post('id', true));
        $run = $this->db->update($this->table, [
            'role_id' => $this->input->post('role', true),
            'username' => $this->input->post('username', true),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        if ($run) {
            echo json_encode([
                'status' => 'success',
                'msg' => 'Data berhasil disimpan'
            ]);
        }
    }
}

/* End of file Home.php */
