<style>
    .glow:hover {
        box-shadow: 0px 0px 5px 0px rgb(67, 165, 245);
    }
</style>
<!-- Page Content -->
<div class="content">

    <h2 class="content-heading"><?= $title ?></h2>

    <div class="block glow">
        <div style="height: 100px;background-image: url('<?= base_url('uploads/img/bg.jpg') ?>');" class="block-content d-flex justify-content-center">
            <h1 style="color: #fff; -webkit-text-stroke: 2px #000;" class="align-self-center">Kelola Data User</h1>
        </div>
    </div>

    <div class="block glow">
        <div class="block-header block-header-default">
            <h3 class="block-title">Table Data</h3>
            <button type="button" class="btn btn-primary btn-square float-right" id="tombol_tambah"><i class="fa fa-plus"></i> Tambah Data</button>
        </div>
        <div class="block-content">

            <table widht="100%" id="table_data" class="table table-striperd">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Role</th>
                        <th>Username</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody id="table_body"></tbody>
            </table>

        </div>
    </div>

</div>
<!-- END Page Content -->